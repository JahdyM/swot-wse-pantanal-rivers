Dados de nível da ANA (Hidroweb) por estação fluviométrica

Estacao_<codigo>/
  ANA_<codigo>_sem_nivelamento.csv - cota da régua (m), colunas: data, wse, phase
  ANA_<codigo>_nivelada.csv        - série nivelada (somente estações com nivelamento):
      wse_orto_local  = wse + H ortométrica do zero da régua (param_H_orto_ZR)
      h_elipsoidal    = wse_orto_local + N local (param_N_local)
      wse_swot_ref    = h_elipsoidal - N EGM2008 (param_N_egm2008), referência do SWOT

parametros_nivelamento_ana.json - H ortométrica do zero da régua e N local por estação
