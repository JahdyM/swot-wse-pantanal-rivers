Dados SWOT processados por estação fluviométrica (bacia do Paraguai / Pantanal)

Estacao_<codigo>/
  node_complete_raw.csv    - série WSE do produto L2_HR_RiverSP Node
  reach_complete_raw.csv   - série WSE do produto L2_HR_RiverSP Reach
  pixc_complete_raw.csv    - série WSE extraída da nuvem de pontos L2_HR_PIXC
  raster_complete_raw.csv  - série WSE extraída do produto L2_HR_Raster
  est.gpkg                 - localização da estação
  mask.gpkg                - máscara de água usada na extração
