Dados de altimetria por satélite (estações virtuais) associados às estações fluviométricas

Estacao_<codigo>/
  alt_conv_<codigo>.csv  - série de altimetria escolhida/convertida para a estação
                           (date, wse, source_virtual_station, wse_u, source_selected)
  hydroweb/              - séries Hydroweb (bruto, WSE agregada e WSE individual)
  dahiti/                - séries DAHITI (WSE agregada e WSE individual)

Nem todas as estações têm estação virtual de altimetria próxima.
